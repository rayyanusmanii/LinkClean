async function updatePopup() {
  // 1. Get total count from storage
  const data = await chrome.storage.local.get({ hiddenCount: 0 });
  document.getElementById('total-count').textContent = data.hiddenCount.toLocaleString();

  // 2. Get page-specific count from the content script
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.id) {
    try {
      const response = await chrome.tabs.sendMessage(tab.id, { action: "getPageCount" });
      document.getElementById('page-count').textContent = response?.count || 0;
    } catch (e) {
      // Content script might not be loaded yet
      document.getElementById('page-count').textContent = 0;
    }
  }
}

// Update on load
updatePopup();

// Listen for storage changes to update total count live
chrome.storage.onChanged.addListener((changes) => {
  if (changes.hiddenCount) {
    document.getElementById('total-count').textContent = changes.hiddenCount.newValue.toLocaleString();
  }
});