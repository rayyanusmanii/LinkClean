// YOUR SECURE CLOUD FUNCTION
const CLOUD_FUNCTION_URL = "https://linkedin-filter-proxy-960436206674.us-central1.run.app";

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "checkPost") {

    // We simply send the prompt to your server
    fetch(CLOUD_FUNCTION_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt: request.prompt })
    })
    .then(res => res.json())
    .then(data => {
      // The server does the thinking and just sends back { result: true/false }
      sendResponse({ result: data.result });
    })
    .catch((err) => {
      console.error("Server Connection Error:", err);
      // Default to FALSE (Hide post) if server fails, to keep feed clean
      sendResponse({ result: false }); 
    });

    return true; // Keep the message channel open for the async response
  }
});